package org.example.safar_ai_trip_planner.common.exception;


public class AccessDeniedException extends RuntimeException {

    public AccessDeniedException(String message){
        super(message);
    }
}
