package org.example.safar_ai_trip_planner.common.enums;

public enum PlaceType {
    HOTEL,
    RESTAURANT,
    ATTRACTION
}
