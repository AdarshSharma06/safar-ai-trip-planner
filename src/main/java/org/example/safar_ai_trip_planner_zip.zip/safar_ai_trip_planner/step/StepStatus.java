package org.example.safar_ai_trip_planner.step;

public enum StepStatus {
    PENDING,
    DONE,
    SKIPPED
}
