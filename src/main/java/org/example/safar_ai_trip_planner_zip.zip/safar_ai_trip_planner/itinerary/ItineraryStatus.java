package org.example.safar_ai_trip_planner.itinerary;

public enum ItineraryStatus {
    DRAFT,
    GENERATED,
    ACTIVE,
    COMPLETED
}
